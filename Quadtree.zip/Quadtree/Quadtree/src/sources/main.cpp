#include "../headers/testQuadtrees.h"
#include "../headers/debug.h"

#include <iostream>
using namespace std;

int main()
{
	testQuadtrees();

	return 0;
}
