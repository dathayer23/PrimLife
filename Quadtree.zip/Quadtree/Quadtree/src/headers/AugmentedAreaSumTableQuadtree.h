#ifndef AUGMENTED_AREA_SUM_TABLE_QUADTREE_H
#define AUGMENTED_AREA_SUM_TABLE_QUADTREE_H

#include <math.h>
#include "dmath.h"
#include "debug.h"

#include "Order2StatisticalConcept.h"

namespace za_co_codespot
{
	namespace datastructures
	{
		using math::sqr;

/**
	An implementation of a region quadtree that represents a 
	rectangle and provides access through 2D indexing. The tree
	is static, that is, no modification of the data is allowed.

	This implementation use area sum tables to perform fast mean and
	variance calculations. The area sum tables are augmented with a row 
	and column of zeros to prevent slow and tricky if-then logic in the
	lookups.

	@tparam T A type of the Order2Statistical concept, for instance int 
	or float. 

	For now, the interface is exactly the same as NaiveQuadtree - see that class
	for documentation on the class interface.
*/
template <typename T>
class AugmentedAreaSumTableQuadtree
{
	//Make sure T is the correct type
	BOOST_CONCEPT_ASSERT((Order2StatisticalConcept<T>));

	//Make sure this implementation conforms to the compile time interface
	//This is for the developer 
#ifdef CODE_SPOT_CO_ZA_DEBUG
	BOOST_CONCEPT_ASSERT((QuadtreeConcept<NaiveQuadtree<T>, T>));
#endif

public:
	AugmentedAreaSumTableQuadtree(const T ar[], unsigned int width, unsigned int height, const T & threshold);
	~AugmentedAreaSumTableQuadtree();

	inline unsigned int getWidth() const;
	inline unsigned int getHeight() const;
	const T& operator()(unsigned int x, unsigned int y) const;
	unsigned int getLevel(unsigned int x, unsigned int y) const;
	unsigned int getNodeCount() const;
	
private:
	class Node
	{
	public:
		explicit Node();
		virtual ~Node() = 0;
		virtual inline const T& getValue(unsigned int x, unsigned int y) const = 0;
		virtual inline unsigned int getLevel(unsigned int x, unsigned int y) const = 0;
		virtual unsigned int getNodeCount() const = 0;
	};

	template <unsigned int childCount>
	class BranchNode : public Node
	{
	public:
		explicit BranchNode();
		virtual ~BranchNode();
		virtual unsigned int getNodeCount() const;
	protected:
		Node * mChildren[childCount];
	};

	class RectangularBranchNode : public BranchNode<4>
	{
	public:
		RectangularBranchNode(const T ar[], const T sum_table[], const T sqr_sum_table[], unsigned int width, unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1, const T & threshold_sqr);
		virtual inline const T& getValue(unsigned int x, unsigned int y) const;
		virtual inline unsigned int getLevel(unsigned int x, unsigned int y) const;
	private:
		unsigned int mMidX;
		unsigned int mMidY;
	};

	class HorizontalBranchNode : public BranchNode<2>
	{
	public:
		HorizontalBranchNode(const T ar[], const T sum_table[], const T sqr_sum_table[], unsigned int width, unsigned int x0, unsigned int y0, int unsigned x1, int unsigned y1, const T & threshold_sqr);
		virtual inline const T& getValue(unsigned int x, unsigned int y) const;
		virtual inline unsigned int getLevel(unsigned int x, unsigned int y) const;
	private:
		unsigned int mMidX;
	};

	class VerticalBranchNode : public BranchNode<2>
	{
	public:
		VerticalBranchNode(const T ar[], const T sum_table[], const T sqr_sum_table[], unsigned int width, unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1, const T & threshold_sqr);
		virtual inline const T& getValue(unsigned int x, unsigned int y) const;
		virtual inline unsigned int getLevel(unsigned int x, unsigned int y) const;
	private:
		unsigned int mMidY;
	};

	class LeafNode : public Node
	{
	public:
		LeafNode(const T & value);
		virtual inline const T& getValue(unsigned int x, unsigned int y) const;
		virtual inline unsigned int getNodeCount() const;
		virtual inline unsigned int getLevel(unsigned int x, unsigned int y) const;
	private:
		T mValue;
	};

	static inline T getVariance(const T sqr_sum_table[], unsigned int width, T mean, unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1);
	static inline T getMean(const T sum_table[], unsigned int width, unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1);
	static inline Node * initializeChild(const T ar[], const T sum_table[], const T sqr_sum_table[], unsigned int width, unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1, const T & threshold_sqr);
	static inline const T& access(const T ar[], unsigned int x, unsigned int y, unsigned int width);
	static inline T& access(T ar[], unsigned int x, unsigned int y, unsigned int width);
	static void make_sum_tables(const T ar[], T sum_table[], T sqr_sum_table[], unsigned int width, unsigned int height);

	unsigned int mWidth;
	unsigned int mHeight;
	Node * mRoot;
};

//-------------------------------------------------------------------------------------
// Implementation

template <typename T>
AugmentedAreaSumTableQuadtree<T>::Node::Node()
{
	//nothing to initialize;
}

template <typename T>
AugmentedAreaSumTableQuadtree<T>::Node::~Node()
{
	//?
}

template <typename T>
template<unsigned int childCount>
AugmentedAreaSumTableQuadtree<T>::BranchNode<childCount>::BranchNode():
	Node()
{
	for(unsigned int k = 0; k < childCount; k++)
	{
		mChildren[k] = 0;
	}
}

template <typename T>
template <unsigned int childCount>
AugmentedAreaSumTableQuadtree<T>::BranchNode<childCount>::~BranchNode()
{
	for(unsigned int k = 0; k < childCount; k++)
	{
		delete mChildren[k];
		mChildren[k] = 0;
	}
}

template <typename T>
template<unsigned int childCount>
unsigned int AugmentedAreaSumTableQuadtree<T>::BranchNode<childCount>::getNodeCount() const
{
	unsigned int sum = 1; // 1 for this node

	for(unsigned int k = 0; k < childCount; k++)
	{
		sum += mChildren[k]->getNodeCount();
	}

	return sum;
}

template <typename T>
AugmentedAreaSumTableQuadtree<T>::RectangularBranchNode::RectangularBranchNode(const T ar[], const T sum_table[], const T sqr_sum_table[], unsigned int width, unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1, const T & threshold_sqr):
	BranchNode<4>(),
	mMidX((x0 + x1) / 2),
	mMidY((y0 + y1) / 2)
{
	assert(x0 != x1 + 1);
	assert(y0 != y1 + 1);

	mChildren[0] = AugmentedAreaSumTableQuadtree<T>::initializeChild(ar, sum_table, sqr_sum_table, width, x0, y0, mMidX, mMidY, threshold_sqr);
	mChildren[1] = AugmentedAreaSumTableQuadtree<T>::initializeChild(ar, sum_table, sqr_sum_table, width, mMidX, y0, x1, mMidY, threshold_sqr);
	mChildren[2] = AugmentedAreaSumTableQuadtree<T>::initializeChild(ar, sum_table, sqr_sum_table, width, x0, mMidY, mMidX, y1, threshold_sqr);
	mChildren[3] = AugmentedAreaSumTableQuadtree<T>::initializeChild(ar, sum_table, sqr_sum_table, width, mMidX, mMidY, x1, y1, threshold_sqr);
}

template <typename T>
const T& AugmentedAreaSumTableQuadtree<T>::RectangularBranchNode::getValue(unsigned int x, unsigned int y) const
{
	if (x < mMidX)
	{
		if (y < mMidY)
		{
			return mChildren[0]->getValue(x,y);
		}
		else
		{
			return mChildren[2]->getValue(x,y);
		}
	}
	else
	{
		if (y < mMidY)
		{
			return mChildren[1]->getValue(x,y);
		}
		else
		{
			return mChildren[3]->getValue(x,y);
		}
	}
}

template <typename T>
unsigned int AugmentedAreaSumTableQuadtree<T>::RectangularBranchNode::getLevel(unsigned int x, unsigned int y) const
{
	if (x < mMidX)
	{
		if (y < mMidY)
		{
			return mChildren[0]->getLevel(x,y) + 1;
		}
		else
		{
			return mChildren[2]->getLevel(x,y) + 1;
		}
	}
	else
	{
		if (y < mMidY)
		{
			return mChildren[1]->getLevel(x,y) + 1;
		}
		else
		{
			return mChildren[3]->getLevel(x,y) + 1;
		}
	}
}

//-----------------------------
template <typename T>
AugmentedAreaSumTableQuadtree<T>::HorizontalBranchNode::HorizontalBranchNode(const T ar[], const T sum_table[], const T sqr_sum_table[], unsigned int width, unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1, const T & threshold_sqr):
	BranchNode<2>(),
	mMidX((x0 + x1) / 2)
{
	assert(x0 != x1 + 1);
	assert(y0 != y1 + 1);

	mChildren[0] = AugmentedAreaSumTableQuadtree<T>::initializeChild(ar, sum_table, sqr_sum_table, width, x0, y0, mMidX, y1, threshold_sqr);
	mChildren[1] = AugmentedAreaSumTableQuadtree<T>::initializeChild(ar, sum_table, sqr_sum_table, width, mMidX, y0, x1, y1, threshold_sqr);	
}

template <typename T>
const T& AugmentedAreaSumTableQuadtree<T>::HorizontalBranchNode::getValue(unsigned int x, unsigned int y) const
{
	if (x < mMidX)
	{
		return mChildren[0]->getValue(x,y);
	}
	else
	{
		return mChildren[1]->getValue(x,y);		
	}
}

template <typename T>
unsigned int AugmentedAreaSumTableQuadtree<T>::HorizontalBranchNode::getLevel(unsigned int x, unsigned int y) const
{
	if (x < mMidX)
	{
		return mChildren[0]->getLevel(x,y) + 1;
	}
	else
	{
		return mChildren[1]->getLevel(x,y) + 1;		
	}
}

//------------------------
template <typename T>
AugmentedAreaSumTableQuadtree<T>::VerticalBranchNode::VerticalBranchNode(const T ar[], const T sum_table[], const T sqr_sum_table[], unsigned int width, unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1, const T & threshold_sqr):
	BranchNode<2>(),
	mMidY((y0 + y1) / 2)
{
	assert(y0 != y1 + 1);

	mChildren[0] = AugmentedAreaSumTableQuadtree<T>::initializeChild(ar, sum_table, sqr_sum_table, width, x0, y0, x1, mMidY, threshold_sqr);
	mChildren[1] = AugmentedAreaSumTableQuadtree<T>::initializeChild(ar, sum_table, sqr_sum_table, width, x0, mMidY, x1, y1, threshold_sqr);	
}

template <typename T>
const T& AugmentedAreaSumTableQuadtree<T>::VerticalBranchNode::getValue(unsigned int x, unsigned int y) const
{
	if (y < mMidY)
	{
		return mChildren[0]->getValue(x,y);
	}
	else
	{
		return mChildren[1]->getValue(x,y);
	}
}

template <typename T>
unsigned int AugmentedAreaSumTableQuadtree<T>::VerticalBranchNode::getLevel(unsigned int x, unsigned int y) const
{
	if (y < mMidY)
	{
		return mChildren[0]->getLevel(x,y) + 1;
	}
	else
	{
		return mChildren[1]->getLevel(x,y) + 1;
	}
}
//--------------------

template <typename T>
AugmentedAreaSumTableQuadtree<T>::LeafNode::LeafNode(const T & value):
	Node(),
	mValue(value)
{}

template <typename T>
const T& AugmentedAreaSumTableQuadtree<T>::LeafNode::getValue(unsigned int x, unsigned int y) const
{
	return mValue;
}

template <typename T>
unsigned int AugmentedAreaSumTableQuadtree<T>::LeafNode::getLevel(unsigned int x, unsigned int y) const
{
	return 0;
}

template <typename T>
unsigned int AugmentedAreaSumTableQuadtree<T>::LeafNode::getNodeCount() const
{
	return 1;
}


template <typename T>
AugmentedAreaSumTableQuadtree<T>::AugmentedAreaSumTableQuadtree(const T ar[], unsigned int width, unsigned int height, const T & threshold):
	mWidth(width),
	mHeight(height)
{
	T * sum_table = new T[(width + 1) * (height + 1)];
	T * sqr_sum_table = new T[(width + 1) * (height + 1)];
	make_sum_tables(ar, sum_table, sqr_sum_table, width, height);

	mRoot = initializeChild(ar, sum_table, sqr_sum_table, width, 0, 0, width, height, sqr(threshold));

	delete[] sum_table;
	delete[] sqr_sum_table;
}

template <typename T>
AugmentedAreaSumTableQuadtree<T>::~AugmentedAreaSumTableQuadtree()
{
	delete mRoot;
	mRoot = 0;
}

template <typename T>
unsigned int AugmentedAreaSumTableQuadtree<T>::getWidth() const
{
	return mWidth;
}

template <typename T>
unsigned int AugmentedAreaSumTableQuadtree<T>::getHeight() const
{
	return mHeight;
}

#ifndef access
template <typename T>
const T& AugmentedAreaSumTableQuadtree<T>::access(const T ar[], unsigned int x, unsigned int y, unsigned int width)
{
	return ar[y*width + x];
}

template <typename T>
T& AugmentedAreaSumTableQuadtree<T>::access(T ar[], unsigned int x, unsigned int y, unsigned int width)
{
	return ar[y*width + x];
}
#endif

template <typename T>
void AugmentedAreaSumTableQuadtree<T>::make_sum_tables(const T ar[], T sum_table[], T sqr_sum_table[], unsigned int width, unsigned int height)
{
	unsigned int new_table_width = width + 1;

	for(unsigned int i = 0; i < width + 1; i++)
	{
		access(sum_table, i, 0, new_table_width) = 0;
		access(sqr_sum_table, i, 0, new_table_width) = 0;
	}

	for(unsigned int j = 1; j < height + 1; j++)
	{
		access(sum_table, 0, j, new_table_width) = 0;
		access(sqr_sum_table, 0, j, new_table_width) = 0;
	}

	for(unsigned int i = 1; i < width + 1; i++)
	{
		for(unsigned int j = 1; j < height + 1; j++)
		{
			access(sum_table, i, j, new_table_width) = 
				access(sum_table, i, j - 1, new_table_width) 
				+ access(sum_table, i - 1, j, new_table_width)
				- access(sum_table, i - 1, j - 1, new_table_width)
				+ access(ar, i - 1, j - 1, width);

			access(sqr_sum_table, i, j, new_table_width) = 
				access(sqr_sum_table, i, j - 1, new_table_width) 
				+ access(sqr_sum_table, i - 1, j, new_table_width)
				- access(sqr_sum_table, i - 1, j - 1, new_table_width)
				+ sqr(access(ar, i - 1, j - 1, width));
		}
	}
}

template <typename T>
T AugmentedAreaSumTableQuadtree<T>::getMean(const T sum_table[], unsigned int width, unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1)
{
	assert(x0 <= x1);
	assert(y0 <= y1);

	T sum;
	unsigned int new_table_width = width + 1;

	sum = access(sum_table, x1+1, y1+1, new_table_width) - access(sum_table, x1+1, y0, new_table_width)
				- access(sum_table, x0, y1+1, new_table_width) + access(sum_table, x0, y0, new_table_width);

	return sum / ((x1 - x0 + 1) * (y1 - y0 + 1));
}

template <typename T>
T AugmentedAreaSumTableQuadtree<T>::getVariance(const T sqr_sum_table[], unsigned int width, T mean, unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1)
{
	assert(x0 <= x1);
	assert(y0 <= y1);

	T sum;
	unsigned int new_table_width = width + 1;

	sum = access(sqr_sum_table, x1+1, y1+1, new_table_width) - access(sqr_sum_table, x1+1, y0, new_table_width)
				- access(sqr_sum_table, x0, y1+1, new_table_width) + access(sqr_sum_table, x0, y0, new_table_width);
	
	return sum / ((x1 - x0 + 1) * (y1 - y0 + 1)) - sqr(mean);
}

template <typename T>
const T& AugmentedAreaSumTableQuadtree<T>::operator()(unsigned int x, unsigned int y) const
{
	return mRoot->getValue(x,y);
}

template <typename T>
unsigned int AugmentedAreaSumTableQuadtree<T>::getLevel(unsigned int x, unsigned int y) const
{
	return mRoot->getLevel(x, y);
}

template<typename T>
typename AugmentedAreaSumTableQuadtree<T>::Node * AugmentedAreaSumTableQuadtree<T>::initializeChild(const T ar[], const T sum_table[], const T sqr_sum_table[], unsigned int width, unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1, const T & threshold_sqr)
{
	if (x0 + 1 == x1)
	{
		if (y0 + 1 == y1)
		{ 
			return new LeafNode(access(ar, x0, y0, width));
		}
		else
		{
			return new VerticalBranchNode(ar, sum_table, sqr_sum_table, width, x0, y0, x1, y1, threshold_sqr);
		}
	}
	else
	{
		if (y0 + 1 == y1)
		{ 
			return new HorizontalBranchNode(ar, sum_table, sqr_sum_table, width, x0, y0, x1, y1, threshold_sqr);
		}
	}

	T mean(getMean(sum_table, width, x0, y0, x1 - 1, y1 - 1));
	T variance(getVariance(sqr_sum_table, width, mean, x0, y0, x1 - 1, y1 - 1));

	if(variance <= threshold_sqr)
	{
		return new LeafNode(mean);
	}
	else
	{
		return new RectangularBranchNode(ar, sum_table, sqr_sum_table, width, x0, y0, x1, y1, threshold_sqr);
	}

	assert(0);
}

template<typename T>
unsigned int AugmentedAreaSumTableQuadtree<T>::getNodeCount() const
{
	return mRoot->getNodeCount();
}

} //end namespace datastructures
} //end namespace za_co_codespot

#endif //AUGMENTED_AREA_SUM_TABLE_QUADTREE_H