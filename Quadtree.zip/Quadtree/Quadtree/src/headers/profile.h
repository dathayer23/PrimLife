#ifndef CODE_SPOT_CO_ZA_PROFILE_H_
#define CODE_SPOT_CO_ZA_PROFILE_H_

#include <ctime>
#include <iostream>

/**
	Quick and dirty profiling. Use just for informal tests, not for 
	extensive profiling.
*/

/** 
	Declares a variable that can be used for a clock.
*/
#define DECLARE_CLOCK(var) \
	namespace codespot_co_za \
	{ \
		namespace system \
		{ \
			int var; \
		} \
	}

/** 
	Start the clock. The variable var must be decalred with DECLARE_CLOCK. 
	STRAT_CLOCK starts a block that must be ended with STOP_CLOCK
*/
#define START_CLOCK(var, count) codespot_co_za::system::var = clock(); \
	for(unsigned int _##var##i = 0; _##var##i < (count); _##var##i++) {

/** 
	Stops the clock and prints the elapsed time since the clock was started. 
	The variable var must be decalred with DECLARE_CLOCK. STOP_CLOCK ends the
	back began by START_CLOCK.
*/
#define STOP_CLOCK(var) \
	}\
	{\
		int _current_time = clock(); \
		std::cout << "TIME: " << (_current_time - codespot_co_za::system::var) << std::endl; \
		codespot_co_za::system::var = _current_time; \
	}

#define TIME(statement, var) \
	START_CLOCK(var) \
	{statement} \
	END_CLOCK(var)

#endif //CODE_SPOT_CO_ZA_PROFILE_H_