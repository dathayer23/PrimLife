#ifndef CODE_SPOT_CO_ZA_DEBUG_H
#define CODE_SPOT_CO_ZA_DEBUG_H

#include "macro_util.h"

#define UNREACHABLE 0
#define NOT_IMPLEMENTED 0

#ifdef CODE_SPOT_CO_ZA_DEBUG
#include <iostream>

#define CODE_SPOT_CO_ZA_SKIP_EXIT

#ifdef CODE_SPOT_CO_ZA_SKIP_EXIT



#ifdef assert
#undef assert
#endif //assert

inline void break_to_debugger()
{
__asm int 3;
}

#define assert(cond) \
	MULTI_LINE_MACRO_BEGIN \
		if (!(cond)) \
		{ \
			std::cerr << "ERROR: Assertion Failed in " << __FILE__ << " line: " << __LINE__ << std::endl; \
			std::cerr << std::endl; \
			__debugbreak(); \
		} \
	MULTI_LINE_MACRO_END
#else
	MULTI_LINE_MACRO_BEGIN \
		if (!(cond)) \
		{ \
			std::cerr << "ERROR: Assertion Failed in " << __FILE__ << " line: " << __LINE__ << std::endl; \
			std::cerr << std::endl;\
			std::cerr << "Application will exit. Press <ENTER>..." << std::endl;\
			getchar(); \
			exit(1);\
		}\
	MULTI_LINE_MACRO_END
#endif //   CODE_SPOT_CO_ZA_SKIP_EXIT

#define bugpr(message) std::cerr << "BUG: " << (message) << " in " << __FILE__ << " line: " << __LINE__ << std::endl;
//#define bugpr(message) std::cerr << message << std::endl;
#else //CODE_SPOT_CO_ZA_DEBUG

#ifndef assert
#define assert(cond) //((void) sizeof(cond))
#endif

#endif //CODE_SPOT_CO_ZA_DEBUG
#endif //CODE_SPOT_CO_ZA_DEBUG_H