#ifndef TEST_FUNCTIONS_H
#define TEST_FUNCTIONS_H

#include "../headers/profile.h"

void testQuadtrees();



#endif //TEST_FUNCTIONS_H