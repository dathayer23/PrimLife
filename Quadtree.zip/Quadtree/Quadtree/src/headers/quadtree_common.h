#ifndef QUADTREE_COMMON_H
#define QUADTREE_COMMON_H

namespace za_co_codespot
{
	namespace datastructures
	{

/**
	Quick and dirty implementation for equality of quadtrees.
	
	Probably slow.

	Not suitable for floating point types.

	The function returns false when the dimensions do not match.

	This assumes operators outside the concept Order2Statistical - this
	function is merely used for testing.

*/
template <typename QuadtreeType1, typename QuadtreeType2>
bool operator==(const QuadtreeType1 & quadtree1, const QuadtreeType2 & quadtree2)
{
	if(quadtree1.getWidth() != quadtree2.getWidth())
	{
		return false;
	}

	if(quadtree1.getHeight() != quadtree2.getHeight())
	{
		return false;
	}

	for(unsigned int x = 0; x < quadtree1.getHeight(); x++)
	{
		for(unsigned int y = 0; y < quadtree1.getHeight(); y++)
		{
			if (quadtree1(x, y) != quadtree2(x, y))
			{
				return false;
			}
		}
	}

	return true;
}

/**
	Quick and dirty implementation for mean absolute error between quadtrees.
	
	Probably slow.
	
	Suitable for floating point values.
	
	Can only be used with trees of the smae width and height.

	This assumes operators outside the concept Order2Statistical - this
	function is merely used for testing.
*/
template <typename QuadtreeType1, typename QuadtreeType2>
double error(const QuadtreeType1 & quadtree1, const QuadtreeType2 & quadtree2)
{
	
	assert(quadtree1.getWidth() == quadtree2.getWidth());
	assert(quadtree1.getHeight() == quadtree2.getHeight());

	double error_sum(0.0);

	for(unsigned int x = 0; x < quadtree1.getWidth(); x++)
	{
		for(unsigned int y = 0; y < quadtree1.getHeight(); y++)
		{
			error_sum += abs((double) quadtree1(x, y) - quadtree2(x, y));
		}
	}

	return error_sum/(quadtree1.getWidth() * quadtree1.getHeight());
}

} //end namespace datastructures
} //end namespace za_co_codespot

#endif //QUADTREE_COMMON_H