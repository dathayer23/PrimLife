#ifndef CODESPOT_MACRO_UTIL
#define CODESPOT_MACRO_UTIL


///Use these safe macros
///for avoiding C4127 warnings in visual studio

#define MULTI_LINE_MACRO_BEGIN do {  

#define MULTI_LINE_MACRO_END \
    __pragma(warning(push)) \
    __pragma(warning(disable:4127)) \
    } while(0) \
    __pragma(warning(pop))

#endif //CODESPOT_MACRO_UTIL