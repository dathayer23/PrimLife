#ifndef ORDER2_STATISTICAL_CONCEPT_H
#define ORDER2_STATISTICAL_CONCEPT_H

#include <boost/concept/assert.hpp>
#include <boost/concept/usage.hpp>

namespace za_co_codespot
{
	namespace datastructures
	{

/**
	A class that implements this concept allows second order statistics 
	to be calculated for a sequence of values of this type, that is, the 
	mean and variance.

	Signed numbers such as int and float implement this concept.
	
	A type that conforms to this concept supports the following operations:
	*	construction with 0 as parameter
	*	less than or equal comparisson
	*	assignment
	*   addition
	*   division by unsigned integers
	*   subtraction
	*	function sqr that squares the value.	

	@note Unsigned numbers, although they implement the concept, are still not suitable
	since they might return incorrect results for subtraction.

	@note The sqr function will typically be implemented as x*x, but the concept 
	does not assume this. The implementor is free to implement the sqr function
	anyway he (or she!) wants.
*/
template <typename T>
struct Order2StatisticalConcept
{
public:
	BOOST_CONCEPT_USAGE(Order2StatisticalConcept) 
	{
		T z0(0); //constructor with 0
		bool b = x <= y; //less than or equal to
		
		T z1 = x; //assignable
		T z2 = x + y; //addable
		T z3 = z2 / (unsigned int) 2;//integer divisable
		T z4 = x - y; //difference
		T z5 = sqr(x); //sqr
	}

private:
	T x;
	T y;
};

/**
	The acrhetype of the Order2Statistical concept. 
	
	@note None of the functions
	return "correct" results; only the minimum is done to msake the class compile.
*/
template<typename T>
class Order2StatisticalArchetype
{
public:
	Order2StatisticalArchetype(){};
	Order2StatisticalArchetype(T v){};
	bool operator<=(const Order2StatisticalArchetype<T> other){return true;}
	Order2StatisticalArchetype<T> operator+(const Order2StatisticalArchetype<T> other){return *this;}
	Order2StatisticalArchetype<T> operator/(unsigned int n){return *this;}
	Order2StatisticalArchetype<T> operator-(const Order2StatisticalArchetype<T> other){return *this;}
};

/**
	@note The concept does not assume multiplication is implemented, therefor the
	architype does use multiplication.
*/
template<typename T>
Order2StatisticalArchetype<T> sqr(const Order2StatisticalArchetype<T> & x) {return x;}

} //end namespace datastructures
} //end namespace za_co_codespot

#endif //ORDER2_STATISTICAL_CONCEPT_H