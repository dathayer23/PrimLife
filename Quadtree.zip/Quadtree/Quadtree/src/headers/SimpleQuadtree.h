#ifndef SIMPLE_QUADTREE_H
#define SIMPLE_QUADTREE_H

#include <math.h>
#include "dmath.h"
#include "debug.h"

#include "Order2StatisticalConcept.h"
#include "quadtree_common.h"

namespace za_co_codespot
{
	namespace datastructures
	{
		using math::sqr;

/**
	A simple implementation of a quadtree.

	This implementation differs from the AugmentedAreaSumTableQuadtree implentation in that there is
	only a single node class - no distinction is made between leaf nodes and 
	different branch nodes. This implementation was inspired by the desire to eliminate 
	virtual function calls from the node class.

	@tparam T A type of the Order2Statistical concept, for instance int 
	or float. 

	For now, the interface is exactly the same as NaiveQuadtree - see that class
	for documentation on the class interface.
*/
template <typename T>
class SimpleQuadtree
{
	//Make sure T is the correct type
	BOOST_CONCEPT_ASSERT((Order2StatisticalConcept<T>));

	//Make sure this implementation conforms to the compile time interface
	//This is for the developer 
#ifdef CODE_SPOT_CO_ZA_DEBUG
	BOOST_CONCEPT_ASSERT((QuadtreeConcept<NaiveQuadtree<T>, T>));
#endif
public:

	SimpleQuadtree(const T ar[], unsigned int width, unsigned int height, const T & threshold);
	~SimpleQuadtree();

	inline unsigned int getWidth() const;
	inline unsigned int getHeight() const;

	const T& operator()(unsigned int x, unsigned int y) const;
	unsigned int getLevel(unsigned int x, unsigned int y) const;
	unsigned int getNodeCount() const;
	
private:

	enum NodeType
	{
		LEAF, VERTICAL_BRANCH, HORISONTAL_BRANCH, RECTANGULAR_BRANCH
	};

	/** 
		This quadtree implementation's node type.

		This can be either a leaf node or a branch node, all data is thrown together!
	*/
	class Node
	{
	public:
		Node(T value); //leaf!

		Node(const T ar[], const T sum_table[], const T sqr_sum_table[],
			unsigned int width, unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1, 
			const T& threshold_sqr, NodeType nodeType); //branch

		~Node(); //need not be virtual, since there is no enheritance
		
		inline const T& getValue(unsigned int x, unsigned int y) const;
		inline unsigned int getLevel(unsigned int x, unsigned int y) const;
		unsigned int getNodeCount() const;
		inline NodeType getNodeType() const;

	private:
		Node();

		T mValue;//We use this only if the node is in fact a leaf node
		
		unsigned int mMidX;
		unsigned int mMidY;
		
		unsigned int mChildCount;

		//We use this to know which data types to use.
		NodeType mNodeType;

		/*
			We do not use this if this is a leaf node, and we do not use all 
			of it if it is not a rectangular node. (See the documentation of 
			the NaiveQuadtree for definitions oif these node types).
		*/
		Node * mChildren[4];
	};

	static inline T getVariance(const T sqr_sum_table[], unsigned int width, T mean, unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1);
	static inline T getMean(const T sum_table[], unsigned int width, unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1);
	static inline Node * initializeChild(const T ar[], const T sum_table[], const T sqr_sum_table[], unsigned int width, unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1, const T & threshold_sqr);

	static inline const T& access(const T ar[], unsigned int x, unsigned int y, unsigned int width);
	static inline T& access(T ar[], unsigned int x, unsigned int y, unsigned int width);

	//make area sum tables in one go
	static void make_sum_tables(const T ar[], T sum_table[], T sqr_sum_table[], unsigned int width, unsigned int height);

	unsigned int mWidth;
	unsigned int mHeight;
	Node * mRoot;
};

//-------------------------------------------------------------------------------------
// Implementation

template<typename T>
SimpleQuadtree<T>::Node::Node(T value):
	mValue(value),
	mNodeType(LEAF),
	mChildCount(0)
{}

template<typename T>
SimpleQuadtree<T>::Node::~Node()
{
	for (unsigned int k = 0; k < mChildCount; k++)
	{
		delete mChildren[k];
	}	
}

template <typename T>
unsigned int SimpleQuadtree<T>::Node::getNodeCount() const
{
	unsigned int sum = 1; // 1 for this node

	for(unsigned int k = 0; k < mChildCount; k++)
	{
		sum += mChildren[k]->getNodeCount();
	}

	return sum;
}

template <typename T>
SimpleQuadtree<T>::Node::Node(
	const T ar[], const T sum_table[], const T sqr_sum_table[], 
	unsigned int width, unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1, 
	const T & threshold_sqr, NodeType nodeType):
	mMidX((x0 + x1) / 2),
	mMidY((y0 + y1) / 2),
	mValue(0),	
	mNodeType(nodeType)
{
	assert(x0 != x1 + 1);
	assert(y0 != y1 + 1);

	switch(mNodeType)
	{
	case RECTANGULAR_BRANCH:
		mChildCount = 4;

		mChildren[0] = SimpleQuadtree<T>::initializeChild(ar, sum_table, sqr_sum_table, width, x0, y0, mMidX, mMidY, threshold_sqr);
		mChildren[1] = SimpleQuadtree<T>::initializeChild(ar, sum_table, sqr_sum_table, width, mMidX, y0, x1, mMidY, threshold_sqr);
		mChildren[2] = SimpleQuadtree<T>::initializeChild(ar, sum_table, sqr_sum_table, width, x0, mMidY, mMidX, y1, threshold_sqr);
		mChildren[3] = SimpleQuadtree<T>::initializeChild(ar, sum_table, sqr_sum_table, width, mMidX, mMidY, x1, y1, threshold_sqr);

		break;

	case HORISONTAL_BRANCH:
		mChildCount = 2;

		mChildren[0] = SimpleQuadtree<T>::initializeChild(ar, sum_table, sqr_sum_table, width, x0, y0, mMidX, y1, threshold_sqr);
		mChildren[1] = SimpleQuadtree<T>::initializeChild(ar, sum_table, sqr_sum_table, width, mMidX, y0, x1, y1, threshold_sqr);
		
		break;

	case VERTICAL_BRANCH:
		mChildCount = 2;

		mChildren[0] = SimpleQuadtree<T>::initializeChild(ar, sum_table, sqr_sum_table, width, x0, y0, x1, mMidY, threshold_sqr);
		mChildren[1] = SimpleQuadtree<T>::initializeChild(ar, sum_table, sqr_sum_table, width, x0, mMidY, x1, y1, threshold_sqr);
		
		break;

	case LEAF:
		mChildCount = 0;

		assert(UNREACHABLE);//Leaf nodes are constructed with another constructor
		break;
	default:
		assert(UNREACHABLE);//No other types of nodes.
		break;
	}
}

template <typename T>
const T& SimpleQuadtree<T>::Node::getValue(unsigned int x, unsigned int y) const
{
	switch(mNodeType)
	{
	case RECTANGULAR_BRANCH:
		if (x < mMidX)
		{
			if (y < mMidY)
			{
				return mChildren[0]->getValue(x,y);
			}
			else
			{
				return mChildren[2]->getValue(x,y);
			}
		}
		else
		{
			if (y < mMidY)
			{
				return mChildren[1]->getValue(x,y);
			}
			else
			{
				return mChildren[3]->getValue(x,y);
			}
		}

		break;
	
	case LEAF:
		return mValue;

		break;

	case HORISONTAL_BRANCH:
		if (x < mMidX)
		{
			return mChildren[0]->getValue(x,y);
		}
		else
		{
			return mChildren[1]->getValue(x,y);
		}

		break;

	case VERTICAL_BRANCH:
		if (y < mMidY)
		{
			return mChildren[0]->getValue(x,y);
		}
		else
		{
			return mChildren[1]->getValue(x,y);
		}

		break;	

	default:
		assert(UNREACHABLE);
		return mValue;
		break;
	}
	
}

template <typename T>
unsigned int SimpleQuadtree<T>::Node::getLevel(unsigned int x, unsigned int y) const
{
	switch(mNodeType)
	{
	case LEAF:
		return 0;
		
		break;

	case HORISONTAL_BRANCH:
		if (x < mMidX)
		{
			return mChildren[0]->getLevel(x,y) + 1;
		}
		else
		{
			return mChildren[1]->getLevel(x,y) + 1;
		}

		break;

	case VERTICAL_BRANCH:
		if (y < mMidY)
		{
			return mChildren[0]->getLevel(x,y) + 1;
		}
		else
		{
			return mChildren[1]->getLevel(x,y) + 1;
		}

		break;

	case RECTANGULAR_BRANCH:
		if (x < mMidX)
		{
			if (y < mMidY)
			{
				return mChildren[0]->getLevel(x,y) + 1;
			}
			else
			{
				return mChildren[2]->getLevel(x,y) + 1;
			}
		}
		else
		{
			if (y < mMidY)
			{
				return mChildren[1]->getLevel(x,y) + 1;
			}
			else
			{
				return mChildren[3]->getLevel(x,y) + 1;
			}
		}

		break;

	default:
		assert(UNREACHABLE);
	}

	assert(UNREACHABLE);
}

template <typename T>
SimpleQuadtree<T>::SimpleQuadtree(const T ar[], unsigned int width, unsigned int height, const T & threshold):
	mWidth(width),
	mHeight(height)
{
	T * sum_table = new T[(width + 1) * (height + 1)];
	T * sqr_sum_table = new T[(width + 1) * (height + 1)];
	make_sum_tables(ar, sum_table, sqr_sum_table, width, height);

	mRoot = initializeChild(ar, sum_table, sqr_sum_table, width, 0, 0, width, height, sqr(threshold));

	delete[] sum_table;
	delete[] sqr_sum_table;
}

template <typename T>
SimpleQuadtree<T>::~SimpleQuadtree()
{
	delete mRoot;
	mRoot = 0;
}

template <typename T>
unsigned int SimpleQuadtree<T>::getWidth() const
{
	return mWidth;
}

template <typename T>
unsigned int SimpleQuadtree<T>::getHeight() const
{
	return mHeight;
}

#ifndef access
template <typename T>
const T& SimpleQuadtree<T>::access(const T ar[], unsigned int x, unsigned int y, unsigned int width)
{
	return ar[y*width + x];
}

template <typename T>
T& SimpleQuadtree<T>::access(T ar[], unsigned int x, unsigned int y, unsigned int width)
{
	return ar[y*width + x];
}
#endif

template <typename T>
void SimpleQuadtree<T>::make_sum_tables(const T ar[], T sum_table[], T sqr_sum_table[], unsigned int width, unsigned int height)
{
	unsigned int new_table_width = width + 1;

	for(unsigned int i = 0; i < width + 1; i++)
	{
		access(sum_table, i, 0, new_table_width) = 0;
		access(sqr_sum_table, i, 0, new_table_width) = 0;
	}

	for(unsigned int j = 1; j < height + 1; j++)
	{
		access(sum_table, 0, j, new_table_width) = 0;
		access(sqr_sum_table, 0, j, new_table_width) = 0;
	}

	for(unsigned int i = 1; i < width + 1; i++)
	{
		for(unsigned int j = 1; j < height + 1; j++)
		{
			access(sum_table, i, j, new_table_width) = 
				access(sum_table, i, j - 1, new_table_width) 
				+ access(sum_table, i - 1, j, new_table_width)
				- access(sum_table, i - 1, j - 1, new_table_width)
				+ access(ar, i - 1, j - 1, width);

			access(sqr_sum_table, i, j, new_table_width) = 
				access(sqr_sum_table, i, j - 1, new_table_width) 
				+ access(sqr_sum_table, i - 1, j, new_table_width)
				- access(sqr_sum_table, i - 1, j - 1, new_table_width)
				+ sqr(access(ar, i - 1, j - 1, width));
		}
	}
}

template <typename T>
T SimpleQuadtree<T>::getMean(const T sum_table[], unsigned int width, unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1)
{
	assert(x0 <= x1);
	assert(y0 <= y1);

	T sum;
	unsigned int new_table_width = width + 1;

	sum = access(sum_table, x1+1, y1+1, new_table_width) - access(sum_table, x1+1, y0, new_table_width)
				- access(sum_table, x0, y1+1, new_table_width) + access(sum_table, x0, y0, new_table_width);

	return sum / ((x1 - x0 + 1) * (y1 - y0 + 1));
}

template <typename T>
T SimpleQuadtree<T>::getVariance(const T sqr_sum_table[], unsigned int width, T mean, unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1)
{
	assert(x0 <= x1);
	assert(y0 <= y1);

	T sum;
	unsigned int new_table_width = width + 1;

	sum = access(sqr_sum_table, x1+1, y1+1, new_table_width) - access(sqr_sum_table, x1+1, y0, new_table_width)
				- access(sqr_sum_table, x0, y1+1, new_table_width) + access(sqr_sum_table, x0, y0, new_table_width);
	
	return sum / ((x1 - x0 + 1) * (y1 - y0 + 1)) - sqr(mean);
}

template <typename T>
const T& SimpleQuadtree<T>::operator()(unsigned int x, unsigned int y) const
{
	return mRoot->getValue(x,y);
}

template <typename T>
unsigned int SimpleQuadtree<T>::getLevel(unsigned int x, unsigned int y) const
{
	return mRoot->getLevel(x, y);
}

template<typename T>
typename SimpleQuadtree<T>::Node * SimpleQuadtree<T>::initializeChild(const T ar[], const T sum_table[], const T sqr_sum_table[], unsigned int width, unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1, const T & threshold_sqr)
{
	if (x0 + 1 == x1)
	{
		if (y0 + 1 == y1)
		{ 
			return new Node(access(ar, x0, y0, width));
		}
		else
		{//vert
			return new Node(ar, sum_table, sqr_sum_table, width, x0, y0, x1, y1, threshold_sqr, VERTICAL_BRANCH);
		}
	}
	else
	{
		if (y0 + 1 == y1)
		{ //hor
			return new Node(ar, sum_table, sqr_sum_table, width, x0, y0, x1, y1, threshold_sqr, HORISONTAL_BRANCH);
		}
	}

	T mean(getMean(sum_table, width, x0, y0, x1 - 1, y1 - 1));
	T variance(getVariance(sqr_sum_table, width, mean, x0, y0, x1 - 1, y1 - 1));

	if(variance <= threshold_sqr)
	{
		return new Node(mean);
	}
	else
	{
		return new Node(ar, sum_table, sqr_sum_table, width, x0, y0, x1, y1, threshold_sqr, RECTANGULAR_BRANCH);
	}

	assert(0);
}

template<typename T>
unsigned int SimpleQuadtree<T>::getNodeCount() const
{
	return mRoot->getNodeCount();
}

} //end namespace datastructures
} //end namespace za_co_codespot

#endif //SIMPLE_QUADTREE_H