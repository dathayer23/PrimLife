#ifndef QUADTREE_CONCEPT_H
#define QUADTREE_CONCEPT_H

#include "boost/concept/assert.hpp"
#include "boost/concept/usage.hpp"

namespace za_co_codespot
{
	namespace datastructures
	{

/**
	This concept is provided to make sure all the quadtrees 
	have the same interface (allowing easy switching between 
	implementations).

	The NaiveQuadtree is the Archetype of this concept - the 
	documentation for that class applies to this concept.

	@note This concept is not meant to be used by client 
	code - it is meant to ensure that the different implementations
	are still in synch if they are changed in the future.
*/
template <typename QuadtreeType, typename ValueType>
struct QuadtreeConcept
{
public:
	BOOST_CONCEPT_USAGE(QuadtreeConcept) 
	{
		QuadtreeType quadtree(mData, mWidth, mWidth, mThreshold); //construct
		
		unsigned int width(quadtree.getWidth());
		unsigned int height(quadtree.getHeight());
		ValueType value(quadtree(mCenter, mCenter));
		unsigned int level(quadtree.getLevel(mCenter, mCenter));
		unsigned int nodeCount(quadtree.getNodeCount());
	}

private:
	static const unsigned int mWidth = 10;//Any value will do
	static const unsigned int mCenter = 5;//any value will do as long it's smaller then the width

	ValueType mThreshold;
	ValueType mData[mWidth*mWidth];
};

} //end namespace datastructures
} //end namespace za_co_codespot

#endif //QUADTREE_H