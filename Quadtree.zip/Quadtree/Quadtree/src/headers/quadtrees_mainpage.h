/**
	@mainpage Region quadtree implementations. 
	
	Four different implementations are provided:
	*	NaiveQuadtree
	*	AreaSumTableQuadtree
	*	AugmentedAreaSumQuadtree
	*	SimpleQuadtree
	
	@requires: boost (tested with 1.42.0) only for concept checking. 
	Concept checking can be removed without changing the behaviour
	of the trees.

	@author Herman Tulleken (herman.tulleken@gmail.com)
	@date 2010
	@version 1.0

	See http://www.code-spot.co.za/
*/