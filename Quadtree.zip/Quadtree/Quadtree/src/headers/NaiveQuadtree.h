#ifndef NAIVE_QUADTREE_H
#define NAIVE_QUADTREE_H

#include <math.h>

#include "boost/concept/assert.hpp"

#include "Order2StatisticalConcept.h"
#include "QuadtreeConcept.h"

#include "dmath.h"
#include "debug.h"
#include "profile.h"

namespace za_co_codespot
{
	namespace datastructures
	{
		using math::sqr;

/**
	An implementation of a region quadtree that represents a 
	rectangle and provides access through 2D indexing. The tree
	is static, that is, no modification of the data is allowed.

	This is a very simple implementation; it is not highly optimised.

	@tparam T A type of the Order2Statistical concept, for instance int 
	or float. 
*/
template <typename T>
class NaiveQuadtree
{
	//Make sure T is the correct type
	BOOST_CONCEPT_ASSERT((Order2StatisticalConcept<T>));

	//Make sure this implementation conforms to the compile time interface
	//This is for the developer 
#ifdef CODE_SPOT_CO_ZA_DEBUG
	BOOST_CONCEPT_ASSERT((QuadtreeConcept<NaiveQuadtree<T>, T>));
#endif

public:
	/**
		Constructs a new quadtree from the given array. Only nodes with standard
		deviation higher than the threshold are split.
	*/
	NaiveQuadtree(T ar[], unsigned int width, unsigned int height, T threshold);

	//destructor - releases nodes 
	virtual ~NaiveQuadtree();

	/**
		Returns the width of the rectangle that this quadtree represents.
	*/
	inline unsigned int getWidth() const;
	
	/**
		Returns the height of the rectangle that this quadtree represents.
	*/
	inline unsigned int getHeight() const;

	/**
		Returns the node value containing the pixel (x, y). 
	*/
	const T& operator()(unsigned int x, unsigned int y) const;

	/**
		Returns the tree depth of the pixel (x, y). The root is at level 0.
	*/
	unsigned int getLevel(unsigned int x, unsigned int y) const;

	/**
		Returns the number of nodes in the tree.
	*/
	unsigned int getNodeCount() const;

private:
	
	/** 
		Base class for the nodes of a quadtree.
	*/
	class Node
	{
	public:
		explicit Node();
		virtual ~Node() = 0;

		/** 
			Gets the value of the node that contains the given pixel.

			It is assumed that this value lies in the region that this
			node represents; no checking is done.
		*/
		virtual inline const T& getValue(unsigned int x, unsigned int y) const = 0;

		/**
			Gets the depth of the given pixel relative to this node.

			It is assumed that this value lies in the region that this
			node represents; no checking is done.
		*/
		virtual inline unsigned int getLevel(unsigned int x, unsigned int y) const = 0;

		/**
			Gets the number of nodes (including this one) that represents
			this region of the data. 

			For example, if this node has 4 children, each of which is a leaf node,
			then this method will return 5 (4 chilcren + 1 self).
		*/
		virtual unsigned int getNodeCount() const = 0;
	};

	/**
		A BranchNode is a node that has children.
	*/
	template <unsigned int childCount>
	class BranchNode : public Node
	{
	public:
		explicit BranchNode();
		virtual ~BranchNode();	
		virtual inline const T& getValue(unsigned int x, unsigned int y) const = 0;
		virtual unsigned int getNodeCount() const;
	protected:
		Node * mChildren[childCount];
	};

	/**
		A RectangularBranchNode has 4 children. It can not represent a row or column
		that is only one pixel thick. VerticalBranchNode and HorizontalBranchNode are
		used for these.
	*/
	class RectangularBranchNode : public BranchNode<4>
	{
	public:
		/**
			Constructs a new branchnode from an array and data representing what region
			of the data this node represents.
		*/
		RectangularBranchNode(T ar[], unsigned int width, unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1, T threshold_sqr);
		
		virtual inline const T& getValue(unsigned int x, unsigned int y) const;
		virtual inline unsigned int getLevel(unsigned int x, unsigned int y) const;

	private:
		/** 
			Instead of staring the border coordinates, we need only store the midpoint where the node divides.

			This means we have fewer checks that can be done, but we save in time and space.
		*/ 
		unsigned int mMidX;
		unsigned int mMidY;
	};

	/**
		Represents a row in the data that is one pixel thick. This node has 2 children.
	*/
	class HorizontalBranchNode : public BranchNode<2>
	{
	public:
		HorizontalBranchNode(T ar[], unsigned int width, unsigned int x0, unsigned int y0, int unsigned x1, int unsigned y1, T threshold_sqr);
		
		virtual inline const T& getValue(unsigned int x, unsigned int y) const;
		virtual inline unsigned int getLevel(unsigned int x, unsigned int y) const;
	private:
		
		unsigned int mMidX;
	};

	/**
		Represents a column in the data that is one pixel thick. This node has 2 children.
	*/
	class VerticalBranchNode : public BranchNode<2>
	{
	public:
		VerticalBranchNode(T ar[], unsigned int width, unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1, T threshold_sqr);

		virtual inline const T& getValue(unsigned int x, unsigned int y) const;
		virtual inline unsigned int getLevel(unsigned int x, unsigned int y) const;
	private:
		unsigned int mMidY;
	};

	class LeafNode : public Node
	{
	public:
		LeafNode(T value);
		virtual inline const T& getValue(unsigned int x, unsigned int y) const;
		virtual unsigned int getNodeCount() const;
		virtual inline unsigned int getLevel(unsigned int x, unsigned int y) const;
	private:
		/* 
			The data from the array that this leaf represents.
			Only leaf nodes have data. The leaf need not represent a
			single pixel. If more than one pixel is represented, this value
			is the mean of all the pixels from the original data that this 
			node represents.
		*/
		T mValue;
	};


	/**
		Gets the mean in the pixel range [x0 x1) x [y0 y1).
	*/
	static T getMean(T ar[], unsigned int width, unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1);
	
	/**
		Gets the variance in the pixel range [x0 x1) x [y0 y1), provided that the mean is given 
		(it should be caluclated by the getMean function). This function does not calculate the 
		mean, it must be done only once.
	*/
	static T getVariance(T ar[], unsigned int width, T mean, unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1);

	/** 
		This function returns an appropriate node for the region
		between [x0, x1) x [y0, y1). This is called recursively.
	*/
	static Node * initializeChild(T ar[], unsigned int width, unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1, T threshold_sqr);

	/**
		The root node, representing the entire image.
	*/
	Node * mRoot;

	/**
		The width of the data that this quadtree represents.
	*/
	unsigned int mWidth;
	
	/**
		The height of the data that this quadtree represents.
	*/
	unsigned int mHeight;
};

//-------------------------------------------------------------------------------------
// Implementation

template <typename T>
NaiveQuadtree<T>::Node::Node()
{
	//nothing to initialize;
}

template <typename T>
NaiveQuadtree<T>::Node::~Node()
{
	//nothing to release;
}

template <typename T>
template <unsigned int childCount>
NaiveQuadtree<T>::BranchNode<childCount>::~BranchNode()
{
	for(unsigned int k = 0; k < childCount; k++)
	{
		delete mChildren[k];
		mChildren[k] = 0;
	}
}

template <typename T>
template <unsigned int childCount>
NaiveQuadtree<T>::BranchNode<childCount>::BranchNode():
	Node()
{
	for(unsigned int k = 0; k < childCount; k++)
	{
		// Initilise to 0 and use asserts later to make 
		// sure we don't have initilised to proper values
		// or are not accessing the worng part of the array.
		mChildren[k] = 0;
	}
}

template <typename T>
template <unsigned int childCount>
unsigned int NaiveQuadtree<T>::BranchNode<childCount>::getNodeCount() const
{
	unsigned int sum = 1; // 1 for this node

	for(unsigned int k = 0; k < childCount; k++)
	{
		assert(mChildren[k] != 0); //See constructor

		sum += mChildren[k]->getNodeCount();
	}

	return sum;
}

template <typename T>
NaiveQuadtree<T>::RectangularBranchNode::RectangularBranchNode(T ar[], unsigned int width, unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1, T threshold_sqr):
	BranchNode<4>(),
	mMidX((x0 + x1) / 2),
	mMidY((y0 + y1) / 2)
{
	assert(x0 != x1 + 1);
	assert(y0 != y1 + 1);

	mChildren[0] = NaiveQuadtree<T>::initializeChild(ar, width, x0, y0, mMidX, mMidY, threshold_sqr);
	mChildren[1] = NaiveQuadtree<T>::initializeChild(ar, width, mMidX, y0, x1, mMidY, threshold_sqr);
	mChildren[2] = NaiveQuadtree<T>::initializeChild(ar, width, x0, mMidY, mMidX, y1, threshold_sqr);
	mChildren[3] = NaiveQuadtree<T>::initializeChild(ar, width, mMidX, mMidY, x1, y1, threshold_sqr);
	
}

template <typename T>
const T& NaiveQuadtree<T>::RectangularBranchNode::getValue(unsigned int x, unsigned int y) const
{
	if (x < mMidX)
	{
		if (y < mMidY)
		{
			return mChildren[0]->getValue(x,y);
		}
		else
		{
			return mChildren[2]->getValue(x,y);
		}
	}
	else
	{
		if (y < mMidY)
		{
			return mChildren[1]->getValue(x,y);
		}
		else
		{
			return mChildren[3]->getValue(x,y);
		}
	}
}

template <typename T>
unsigned int NaiveQuadtree<T>::RectangularBranchNode::getLevel(unsigned int x, unsigned int y) const
{
	if (x < mMidX)
	{
		if (y < mMidY)
		{
			return mChildren[0]->getLevel(x,y) + 1;
		}
		else
		{
			return mChildren[2]->getLevel(x,y) + 1;
		}
	}
	else
	{
		if (y < mMidY)
		{
			return mChildren[1]->getLevel(x,y) + 1;
		}
		else
		{
			return mChildren[3]->getLevel(x,y) + 1;
		}
	}
}

//-----------------------------
template <typename T>
NaiveQuadtree<T>::HorizontalBranchNode::HorizontalBranchNode(T ar[], unsigned int width, unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1, T threshold_sqr):
	BranchNode<2>(),
	mMidX((x0 + x1) / 2)
{
	assert(x0 != x1 + 1);
	assert(y0 != y1 + 1);

	mChildren[0] = NaiveQuadtree<T>::initializeChild(ar, width, x0, y0, mMidX, y1, threshold_sqr);
	mChildren[1] = NaiveQuadtree<T>::initializeChild(ar, width, mMidX, y0, x1, y1, threshold_sqr);	
}

template <typename T>
const T& NaiveQuadtree<T>::HorizontalBranchNode::getValue(unsigned int x, unsigned int y) const
{
	if (x < mMidX)
	{
		return mChildren[0]->getValue(x,y);
	}
	else
	{
		return mChildren[1]->getValue(x,y);		
	}
}

template <typename T>
unsigned int NaiveQuadtree<T>::HorizontalBranchNode::getLevel(unsigned int x, unsigned int y) const
{
	if (x < mMidX)
	{
		return mChildren[0]->getLevel(x,y) + 1;
	}
	else
	{
		return mChildren[1]->getLevel(x,y) + 1;		
	}
}
//------------------------
template <typename T>
NaiveQuadtree<T>::VerticalBranchNode::VerticalBranchNode(T ar[], unsigned int width, unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1, T threshold_sqr):
	BranchNode<2>(),
	mMidY((y0 + y1) / 2)
{
	assert(x0 != x1 + 1);
	assert(y0 != y1 + 1);

	mChildren[0] = NaiveQuadtree<T>::initializeChild(ar, width, x0, y0, x1, mMidY, threshold_sqr);
	mChildren[1] = NaiveQuadtree<T>::initializeChild(ar, width, x0, mMidY, x1, y1, threshold_sqr);	
}

template <typename T>
const T& NaiveQuadtree<T>::VerticalBranchNode::getValue(unsigned int x, unsigned int y) const
{
	if (y < mMidY)
	{
		return mChildren[0]->getValue(x,y);
	}
	else
	{
		return mChildren[1]->getValue(x,y);
	}
}

template <typename T>
unsigned int NaiveQuadtree<T>::VerticalBranchNode::getLevel(unsigned int x, unsigned int y) const
{
	if (y < mMidY)
	{
		return mChildren[0]->getLevel(x,y) + 1;
	}
	else
	{
		return mChildren[1]->getLevel(x,y) + 1;
	}
}
//--------------------

template <typename T>
NaiveQuadtree<T>::LeafNode::LeafNode(T value):
	Node(),
	mValue(value)
{}

template <typename T>
const T& NaiveQuadtree<T>::LeafNode::getValue(unsigned int x, unsigned int y) const
{
	return mValue;
}

template <typename T>
unsigned int NaiveQuadtree<T>::LeafNode::getLevel(unsigned int x, unsigned int y) const
{
	return 0;
}

template <typename T>
unsigned int NaiveQuadtree<T>::LeafNode::getNodeCount() const
{
	return 1;
}

template <typename T>
NaiveQuadtree<T>::NaiveQuadtree(T ar[], unsigned int width, unsigned int height, T threshold):
	mWidth(width),
	mHeight(height),
	mRoot(initializeChild(ar, width, 0, 0, width, height, sqr(threshold)))
{}

template <typename T>
NaiveQuadtree<T>::~NaiveQuadtree()
{
	delete mRoot;
	mRoot = 0;
}

template <typename T>
unsigned int NaiveQuadtree<T>::getWidth() const
{
	return mWidth;
}

template <typename T>
unsigned int NaiveQuadtree<T>::getHeight() const
{
	return mHeight;
}

template <typename T>
T NaiveQuadtree<T>::getMean(T ar[], unsigned int width, unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1)
{
	T sum(0);

	assert(x0 != x1);
	assert(y0 != y1);

	for(unsigned int i = x0; i < x1; i++)
	{
		for(unsigned int j = y0; j < y1; j++)
		{
			sum = sum + ar[j * width + i];
		}
	}

	return sum / ((x1 - x0) * (y1 - y0));
}

template <typename T>
T NaiveQuadtree<T>::getVariance(T ar[], unsigned int width, T mean, unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1)
{
	T sum(0);

	assert(x0 != x1);
	assert(y0 != y1);

	for(unsigned int i = x0; i < x1; i++)
	{
		for(unsigned int j = y0; j < y1; j++)
		{
			sum = sum + sqr(mean - ar[j * width + i]);
		}
	}
	
	return sum / ((x1 - x0) * (y1 - y0));
}

template <typename T>
const T& NaiveQuadtree<T>::operator()(unsigned int x, unsigned int y) const
{
	return mRoot->getValue(x,y);
}

template <typename T>
unsigned int NaiveQuadtree<T>::getLevel(unsigned int x, unsigned int y) const
{
	return mRoot->getLevel(x, y);
}

template<typename T>
typename NaiveQuadtree<T>::Node * NaiveQuadtree<T>::initializeChild(T ar[], unsigned int width, unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1, T threshold_sqr)
{
	if (x0 + 1 == x1)//one pixel wide
	{
		if (y0 + 1 == y1)//one pixel high
		{ 
			return new LeafNode(ar[y0*width + x0]);
		}
		else
		{
			return new VerticalBranchNode(ar, width, x0, y0, x1, y1, threshold_sqr);
		}
	}
	else
	{
		if (y0 + 1 == y1)//one pixel high
		{ 
			return new HorizontalBranchNode(ar, width, x0, y0, x1, y1, threshold_sqr);
		}
	}

	T mean(getMean(ar, width, x0, y0, x1, y1));
	T variance(getVariance(ar, width, mean, x0, y0, x1, y1));

	/*
		We use the variance in calculations, rather than the standard deviation so that 
		we need not call an expensive square root function here.

		Note that we use <= rather than < so that we can always have 
		a consistent behaviour when threshold is 0 for any (numeric) type.
	*/
	if(variance <= threshold_sqr)
	{
		return new LeafNode(mean);
	}
	else
	{
		return new RectangularBranchNode(ar, width, x0, y0, x1, y1, threshold_sqr);
	}

	assert(UNREACHABLE);
}

template<typename T>
unsigned int NaiveQuadtree<T>::getNodeCount() const
{
	return mRoot->getNodeCount();
}

} //end namespace datastructures
} //end namespace za_co_codespot

#endif //NAIVE_QUADTREE_H