#ifndef AREA_SUM_TABLE_QUADTREE_H
#define AREA_SUM_TABLE_QUADTREE_H

#include <math.h>
#include "dmath.h"
#include "debug.h"

#include "Order2StatisticalConcept.h"

namespace za_co_codespot
{
	namespace datastructures
	{
		using math::sqr;

/**
	An implementation of a region quadtree that represents a 
	rectangle and provides access through 2D indexing. The tree
	is static, that is, no modification of the data is allowed.

	This implementation use area sum tables to perform fast mean and
	variance calculations.

	@tparam T A type of the Order2Statistical concept, for instance int 
	or float. 

	For now, the interface is exactly the same as NaiveQuadtree - see that class
	for documentation on the class interface.
*/
template <typename T>
class AreaSumTableQuadtree
{
	//Make sure T is the correct type
	BOOST_CONCEPT_ASSERT((Order2StatisticalConcept<T>));

	//Make sure this implementation conforms to the compile time interface
	//This is for the developer 
#ifdef CODE_SPOT_CO_ZA_DEBUG
	BOOST_CONCEPT_ASSERT((QuadtreeConcept<NaiveQuadtree<T>, T>));
#endif

public:
	AreaSumTableQuadtree(const T ar[], unsigned int width, unsigned int height, const T & threshold);
	~AreaSumTableQuadtree();

	inline unsigned int getWidth() const;
	inline unsigned int getHeight() const;

	const T& operator()(unsigned int x, unsigned int y) const;
	unsigned int getLevel(unsigned int x, unsigned int y) const;
	unsigned int getNodeCount() const;
	
private:

	class Node
	{
	public:
		explicit Node();
		virtual ~Node() = 0;
		virtual inline const T& getValue(unsigned int x, unsigned int y) const = 0;
		virtual inline unsigned int getLevel(unsigned int x, unsigned int y) const = 0;
		virtual unsigned int getNodeCount() const = 0;
	};

	template <unsigned int childCount>
	class BranchNode : public Node
	{
	public:
		explicit BranchNode();
		virtual ~BranchNode();
		virtual unsigned int getNodeCount() const;
	protected:
		Node * mChildren[childCount];
	};

	class RectangularBranchNode : public BranchNode<4>
	{
	public:
		RectangularBranchNode(const T ar[], const T sum_table[], const T sqr_sum_table[], unsigned int width, unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1, const T & threshold_sqr);
		virtual inline const T& getValue(unsigned int x, unsigned int y) const;
		virtual inline unsigned int getLevel(unsigned int x, unsigned int y) const;
	private:
		unsigned int mMidX;
		unsigned int mMidY;
	};

	class HorizontalBranchNode : public BranchNode<2>
	{
	public:
		HorizontalBranchNode(const T ar[], const T sum_table[], const T sqr_sum_table[], unsigned int width, unsigned int x0, unsigned int y0, int unsigned x1, int unsigned y1, const T & threshold_sqr);
		virtual inline const T& getValue(unsigned int x, unsigned int y) const;
		virtual inline unsigned int getLevel(unsigned int x, unsigned int y) const;
	private:
		unsigned int mMidX;
	};

	class VerticalBranchNode : public BranchNode<2>
	{
	public:
		VerticalBranchNode(const T ar[], const T sum_table[], const T sqr_sum_table[], unsigned int width, unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1, const T & threshold_sqr);
		virtual inline const T& getValue(unsigned int x, unsigned int y) const;
		virtual inline unsigned int getLevel(unsigned int x, unsigned int y) const;
	private:
		unsigned int mMidY;
	};

	class LeafNode : public Node
	{
	public:
		LeafNode(const T & value);
		virtual inline const T& getValue(unsigned int x, unsigned int y) const;
		virtual inline unsigned int getNodeCount() const;
		virtual inline unsigned int getLevel(unsigned int x, unsigned int y) const;
	private:
		T mValue;
	};

	static inline T getVariance(const T sqr_sum_table[], unsigned int width, T mean, unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1);
	static inline T getMean(const T sum_table[], unsigned int width, unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1);
	static inline Node * initializeChild(const T ar[], const T sum_table[], const T sqr_sum_table[], unsigned int width, unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1, const T & threshold_sqr);
	static inline const T& access(const T ar[], unsigned int x, unsigned int y, unsigned int width);
	static inline T& access(T ar[], unsigned int x, unsigned int y, unsigned int width);
	static void make_sum_tables(const T ar[], T sum_table[], T sqr_sum_table[], unsigned int width, unsigned int height);

	unsigned int mWidth;
	unsigned int mHeight;
	Node * mRoot;
};

//-------------------------------------------------------------------------------------
// Implementation

template <typename T>
AreaSumTableQuadtree<T>::Node::Node()
{
	//nothing to initialize;
}

template <typename T>
AreaSumTableQuadtree<T>::Node::~Node()
{
	//?
}

template <typename T>
template <unsigned int childCount>
AreaSumTableQuadtree<T>::BranchNode<childCount>::BranchNode():
	Node()
{
	for(unsigned int k = 0; k < childCount; k++)
	{
		mChildren[k] = 0;
	}
}

template <typename T>
template<unsigned int childCount>
AreaSumTableQuadtree<T>::BranchNode<childCount>::~BranchNode()
{
	for(unsigned int k = 0; k < childCount; k++)
	{
		delete mChildren[k];
		mChildren[k] = 0;
	}
}

template <typename T>
template<unsigned int childCount>
unsigned int AreaSumTableQuadtree<T>::BranchNode<childCount>::getNodeCount() const
{
	unsigned int sum = 1; // 1 for this node

	for(unsigned int k = 0; k < childCount; k++)
	{
		sum += mChildren[k]->getNodeCount();
	}

	return sum;
}

template <typename T>
AreaSumTableQuadtree<T>::RectangularBranchNode::RectangularBranchNode(const T ar[], const T sum_table[], const T sqr_sum_table[], unsigned int width, unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1, const T & threshold_sqr):
	BranchNode<4>(),
	mMidX((x0 + x1) / 2),
	mMidY((y0 + y1) / 2)
{
	assert(x0 != x1 + 1);
	assert(y0 != y1 + 1);

	mChildren[0] = AreaSumTableQuadtree<T>::initializeChild(ar, sum_table, sqr_sum_table, width, x0, y0, mMidX, mMidY, threshold_sqr);
	mChildren[1] = AreaSumTableQuadtree<T>::initializeChild(ar, sum_table, sqr_sum_table, width, mMidX, y0, x1, mMidY, threshold_sqr);
	mChildren[2] = AreaSumTableQuadtree<T>::initializeChild(ar, sum_table, sqr_sum_table, width, x0, mMidY, mMidX, y1, threshold_sqr);
	mChildren[3] = AreaSumTableQuadtree<T>::initializeChild(ar, sum_table, sqr_sum_table, width, mMidX, mMidY, x1, y1, threshold_sqr);
}



template <typename T>
const T& AreaSumTableQuadtree<T>::RectangularBranchNode::getValue(unsigned int x, unsigned int y) const
{
	if (x < mMidX)
	{
		if (y < mMidY)
		{
			return mChildren[0]->getValue(x,y);
		}
		else
		{
			return mChildren[2]->getValue(x,y);
		}
	}
	else
	{
		if (y < mMidY)
		{
			return mChildren[1]->getValue(x,y);
		}
		else
		{
			return mChildren[3]->getValue(x,y);
		}
	}
}

template <typename T>
unsigned int AreaSumTableQuadtree<T>::RectangularBranchNode::getLevel(unsigned int x, unsigned int y) const
{
	if (x < mMidX)
	{
		if (y < mMidY)
		{
			return mChildren[0]->getLevel(x,y) + 1;
		}
		else
		{
			return mChildren[2]->getLevel(x,y) + 1;
		}
	}
	else
	{
		if (y < mMidY)
		{
			return mChildren[1]->getLevel(x,y) + 1;
		}
		else
		{
			return mChildren[3]->getLevel(x,y) + 1;
		}
	}
}

//-----------------------------
template <typename T>
AreaSumTableQuadtree<T>::HorizontalBranchNode::HorizontalBranchNode(const T ar[], const T sum_table[], const T sqr_sum_table[], unsigned int width, unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1, const T & threshold_sqr):
	BranchNode<2>(),
	mMidX((x0 + x1) / 2)
{
	assert(x0 != x1 + 1);
	assert(y0 != y1 + 1);

	mChildren[0] = AreaSumTableQuadtree<T>::initializeChild(ar, sum_table, sqr_sum_table, width, x0, y0, mMidX, y1, threshold_sqr);
	mChildren[1] = AreaSumTableQuadtree<T>::initializeChild(ar, sum_table, sqr_sum_table, width, mMidX, y0, x1, y1, threshold_sqr);	
}

template <typename T>
const T& AreaSumTableQuadtree<T>::HorizontalBranchNode::getValue(unsigned int x, unsigned int y) const
{
	if (x < mMidX)
	{
		return mChildren[0]->getValue(x,y);
	}
	else
	{
		return mChildren[1]->getValue(x,y);		
	}
}

template <typename T>
unsigned int AreaSumTableQuadtree<T>::HorizontalBranchNode::getLevel(unsigned int x, unsigned int y) const
{
	if (x < mMidX)
	{
		return mChildren[0]->getLevel(x,y) + 1;
	}
	else
	{
		return mChildren[1]->getLevel(x,y) + 1;		
	}
}

//------------------------
template <typename T>
AreaSumTableQuadtree<T>::VerticalBranchNode::VerticalBranchNode(const T ar[], const T sum_table[], const T sqr_sum_table[], unsigned int width, unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1, const T & threshold_sqr):
	BranchNode<2>(),
	mMidY((y0 + y1) / 2)
{
	assert(y0 != y1 + 1);

	mChildren[0] = AreaSumTableQuadtree<T>::initializeChild(ar, sum_table, sqr_sum_table, width, x0, y0, x1, mMidY, threshold_sqr);
	mChildren[1] = AreaSumTableQuadtree<T>::initializeChild(ar, sum_table, sqr_sum_table, width, x0, mMidY, x1, y1, threshold_sqr);	
}

template <typename T>
const T& AreaSumTableQuadtree<T>::VerticalBranchNode::getValue(unsigned int x, unsigned int y) const
{
	if (y < mMidY)
	{
		return mChildren[0]->getValue(x,y);
	}
	else
	{
		return mChildren[1]->getValue(x,y);
	}
}

template <typename T>
unsigned int AreaSumTableQuadtree<T>::VerticalBranchNode::getLevel(unsigned int x, unsigned int y) const
{
	if (y < mMidY)
	{
		return mChildren[0]->getLevel(x,y) + 1;
	}
	else
	{
		return mChildren[1]->getLevel(x,y) + 1;
	}
}
//--------------------

template <typename T>
AreaSumTableQuadtree<T>::LeafNode::LeafNode(const T & value):
	Node(),
	mValue(value)
{}

template <typename T>
const T& AreaSumTableQuadtree<T>::LeafNode::getValue(unsigned int x, unsigned int y) const
{
	return mValue;
}

template <typename T>
unsigned int AreaSumTableQuadtree<T>::LeafNode::getLevel(unsigned int x, unsigned int y) const
{
	return 0;
}

template <typename T>
unsigned int AreaSumTableQuadtree<T>::LeafNode::getNodeCount() const
{
	return 1;
}


template <typename T>
AreaSumTableQuadtree<T>::AreaSumTableQuadtree(const T ar[], unsigned int width, unsigned int height, const T & threshold):
	mWidth(width),
	mHeight(height)
{
	T * sum_table = new T[width*height];
	T * sqr_sum_table = new T[width*height];
	make_sum_tables(ar, sum_table, sqr_sum_table, width, height);

	mRoot = initializeChild(ar, sum_table, sqr_sum_table, width, 0, 0, width, height, sqr(threshold));

	delete[] sum_table;
	delete[] sqr_sum_table;
}

template <typename T>
AreaSumTableQuadtree<T>::~AreaSumTableQuadtree()
{
	delete mRoot;
	mRoot = 0;
}

template <typename T>
unsigned int AreaSumTableQuadtree<T>::getWidth() const
{
	return mWidth;
}

template <typename T>
unsigned int AreaSumTableQuadtree<T>::getHeight() const
{
	return mHeight;
}

#ifndef access
template <typename T>
const T& AreaSumTableQuadtree<T>::access(const T ar[], unsigned int x, unsigned int y, unsigned int width)
{
	return ar[y*width + x];
}

template <typename T>
T& AreaSumTableQuadtree<T>::access(T ar[], unsigned int x, unsigned int y, unsigned int width)
{
	return ar[y*width + x];
}
#endif

template <typename T>
void AreaSumTableQuadtree<T>::make_sum_tables(const T ar[], T sum_table[], T sqr_sum_table[], unsigned int width, unsigned int height)
{
	access(sum_table, 0, 0, width) = access(ar, 0, 0, width);
	access(sqr_sum_table, 0, 0, width) = sqr(access(ar, 0, 0, width));

	for(unsigned int i = 1; i < width; i++)
	{
		access(sum_table, i, 0, width) = access(sum_table, i - 1, 0, width) + access(ar, i, 0, width);
		access(sqr_sum_table, i, 0, width) = access(sqr_sum_table, i - 1, 0, width) + sqr(access(ar, i, 0, width));
	}

	for(unsigned int j = 1; j < height; j++)
	{
		access(sum_table, 0, j, width) = access(sum_table, 0, j - 1, width) + access(ar, 0, j, width);
		access(sqr_sum_table, 0, j, width) = access(sqr_sum_table, 0, j - 1, width) + sqr(access(ar, 0, j, width));
	}

	for(unsigned int i = 1; i < width; i++)
	{
		for(unsigned int j = 1; j < height; j++)
		{
			access(sum_table, i, j, width) = 
				access(sum_table, i, j - 1, width) 
				+ access(sum_table, i - 1, j, width)
				- access(sum_table, i - 1, j - 1, width)
				+ access(ar, i, j, width);

			access(sqr_sum_table, i, j, width) = 
				access(sqr_sum_table, i, j - 1, width) 
				+ access(sqr_sum_table, i - 1, j, width)
				- access(sqr_sum_table, i - 1, j - 1, width)
				+ sqr(access(ar, i, j, width));
		}
	}
}

template <typename T>
T AreaSumTableQuadtree<T>::getMean(const T sum_table[], unsigned int width, unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1)
{
	assert(x0 <= x1);
	assert(y0 <= y1);

	T sum;

	if (x0 == 0)
	{
		if (y0 == 0)
		{
			sum = access(sum_table, x1, y1, width);
		}
		else
		{
			sum = access(sum_table, x1, y1, width) - access(sum_table, x1, y0 - 1, width);;
		}
	}
	else
	{
		if (y0 == 0)
		{
			sum = access(sum_table, x1, y1, width) - access(sum_table, x0 - 1, y1, width);
		}
		else
		{
			sum = access(sum_table, x1, y1, width) - access(sum_table, x1, y0 - 1, width)
				- access(sum_table, x0 - 1, y1, width) + access(sum_table, x0 - 1, y0 - 1, width);
		}
	}

	return sum / ((x1 - x0 + 1) * (y1 - y0 + 1));
}

template <typename T>
T AreaSumTableQuadtree<T>::getVariance(const T sqr_sum_table[], unsigned int width, T mean, unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1)
{
	assert(x0 <= x1);
	assert(y0 <= y1);

	T sum;

	if (x0 == 0)
	{
		if (y0 == 0)
		{
			sum = access(sqr_sum_table, x1, y1, width);
		}
		else
		{
			sum = access(sqr_sum_table, x1, y1, width) - access(sqr_sum_table, x1, y0 - 1, width);;
		}
	}
	else
	{
		if (y0 == 0)
		{
			sum = access(sqr_sum_table, x1, y1, width) - access(sqr_sum_table, x0 - 1, y1, width);
		}
		else
		{
			sum = access(sqr_sum_table, x1, y1, width) - access(sqr_sum_table, x1, y0 - 1, width)
				- access(sqr_sum_table, x0 - 1, y1, width) + access(sqr_sum_table, x0 - 1, y0 - 1, width);
		}
	}
	
	return sum / ((x1 - x0 + 1) * (y1 - y0 + 1)) - sqr(mean);
}

template <typename T>
const T& AreaSumTableQuadtree<T>::operator()(unsigned int x, unsigned int y) const
{
	return mRoot->getValue(x,y);
}

template <typename T>
unsigned int AreaSumTableQuadtree<T>::getLevel(unsigned int x, unsigned int y) const
{
	return mRoot->getLevel(x, y);
}

template<typename T>
typename AreaSumTableQuadtree<T>::Node * AreaSumTableQuadtree<T>::initializeChild(const T ar[], const T sum_table[], const T sqr_sum_table[], unsigned int width, unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1, const T & threshold_sqr)
{
	if (x0 + 1 == x1)
	{
		if (y0 + 1 == y1)
		{ 
			return new LeafNode(access(ar, x0, y0, width));
		}
		else
		{
			return new VerticalBranchNode(ar, sum_table, sqr_sum_table, width, x0, y0, x1, y1, threshold_sqr);
		}
	}
	else
	{
		if (y0 + 1 == y1)
		{ 
			return new HorizontalBranchNode(ar, sum_table, sqr_sum_table, width, x0, y0, x1, y1, threshold_sqr);
		}
	}

	T mean(getMean(sum_table, width, x0, y0, x1 - 1, y1 - 1));
	T variance(getVariance(sqr_sum_table, width, mean, x0, y0, x1 - 1, y1 - 1));

	if(variance <= threshold_sqr)
	{
		return new LeafNode(mean);
	}
	else
	{
		return new RectangularBranchNode(ar, sum_table, sqr_sum_table, width, x0, y0, x1, y1, threshold_sqr);
	}

	assert(0);
}

template<typename T>
unsigned int AreaSumTableQuadtree<T>::getNodeCount() const
{
	return mRoot->getNodeCount();
}

} //end namespace datastructures
} //end namespace za_co_codespot

#endif //AREA_SUM_TABLE_QUADTREE_H