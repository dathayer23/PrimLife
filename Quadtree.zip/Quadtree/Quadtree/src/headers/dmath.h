#ifndef QMATH_H
#define QMATH_H

namespace za_co_codespot
{
	namespace math
	{

/** 
	Multiplies a value with itself and returns the result.
*/
template <typename T>
T inline sqr(T x);


// Implementation

template <typename T>
T sqr(T x)
{
	return x * x;
}

} //end namespace math
} //end namespace za_co_codespot

#endif //QMATH_H