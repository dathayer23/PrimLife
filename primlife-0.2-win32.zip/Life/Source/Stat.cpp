// Stat.cpp : implementation file
//

#include "stdafx.h"
#include "Primordial Life.h"
#include "Stat.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CStat

IMPLEMENT_DYNCREATE(CStat, CMiniFrameWnd)

CStat::CStat()
{
}

CStat::~CStat()
{
}


BEGIN_MESSAGE_MAP(CStat, CMiniFrameWnd)
	//{{AFX_MSG_MAP(CStat)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CStat message handlers
