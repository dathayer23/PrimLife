#if !defined(AFX_STAT_H__55CB0282_5372_11D1_8879_F2A14744743F__INCLUDED_)
#define AFX_STAT_H__55CB0282_5372_11D1_8879_F2A14744743F__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// Stat.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CStat frame

class CStat : public CMiniFrameWnd
{
	DECLARE_DYNCREATE(CStat)
protected:
	CStat();           // protected constructor used by dynamic creation

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CStat)
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CStat();

	// Generated message map functions
	//{{AFX_MSG(CStat)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STAT_H__55CB0282_5372_11D1_8879_F2A14744743F__INCLUDED_)
